#'Likelihood ratio (residual sum of squares) statistic distribution with sample splitting
#'
#' Monte Carlo'd distribution of the "Sbar" statistic for different number of
#' folds KK, including KK=1.  For KK in 1:20.
#'
#' @format A matrix of dimensions (maxKK, NumSims, numBetas) of numeric
#'   values (quantiles of the given distribution).  As an array it is indexed
#'   by "beta" (flatness) and by KK.  So e.g. LRstat_distn_SS_mat[10, , "1"]
#'   is the distribution for 10-fold cross fitting with flatness level 1.
#'
#'
#' Beta  values are: "0.01" "0.2" "0.4" "0.6" "0.8" "1" "2" "5"
"LRstat_distn_SS_mat"
