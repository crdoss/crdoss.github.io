get_pvalue_matrix <-
function(X, resid, rho=1/2, k=3) {
    p <- ncol(X) ## number of covariates
    n <- nrow(X) ## sample size
    
    ## Initialize data frames
    ref <- data.frame() ## reference set
    ev <- data.frame() ## evaluation set
    group_ref <- data.frame() ## group IDs for reference set
    group_ev <- data.frame() ## group IDs for evaluation set
    
    ## Sort X by residual values and sort the residual vector
    X <- X[sort(resid, index.return=TRUE)$ix, ]
    resid <- sort(resid)
    
    ref_ind <- sample(1:n, size=floor(rho*n), replace=FALSE) ## indices for reference set
    ## Separate reference and evaluation set data for each covariate
    for (i in 1:p) {
        ref[1:length(ref_ind), i] <- abs(resid[ref_ind][sort(X[ref_ind, i], 
                                                             index.return=TRUE)$ix])
        ev[1:(n-length(ref_ind)), i] <- abs(resid[-ref_ind][sort(X[-ref_ind, i], 
                                                                 index.return=TRUE)$ix])
    }
    
    pvals <- data.frame()
    n_ref <- c(0, floor(c(1:k) * nrow(ref) / k)) ## Indices for subgroups, reference set
    n_ev <- c(0, floor(c(1:k) * nrow(ev) / k)) ## Indices for subgroups, evaluation set
    for (i in 1:p) {
        for (j in 1:k) {
            ## Calculate empirical p-value for every evaluation set residual
            ev_vec <- ev[(n_ev[j]+1):n_ev[j+1], i]
            ref_vec <- ref[-((n_ref[j]+1):n_ref[j+1]), i]
            denom <- length(ref_vec)
            beat_vec <- sapply(ev_vec, FUN=get_n_beat, y=ref_vec)
            pvals[(n_ev[j]+1):n_ev[j+1], i] <- 1 - beat_vec / denom
            ## Store subgroup identity for every residual
            group_ref[(n_ref[j]+1):n_ref[j+1], i] <- j
            group_ev[(n_ev[j]+1):n_ev[j+1], i] <- j
        }
    }
    
    ## Return p-values, subgroups indices, and reference and evaluation sets
    list("probs"=pvals, "n_ref"=n_ref, "n_ev"=n_ev, 
         "group_ref"=group_ref, "group_ev"=group_ev, "ref"=ref, "ev"=ev)
}
