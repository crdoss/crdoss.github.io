
## Why is 'size' set to 1000; I think 1000 should be replaced by N.

generate_three_point_data <-
function(N, p ,d){
  Sigma <- 4 * diag(p)

  X <- abs(mvrnorm(N, mu=rep(5, p), Sigma))

  a <- (-1 - sqrt(21)) / 4
  b <- (sqrt(21) - 1) / 4
  c <- 1/2

  if (d == 0) eps <- rnorm(N, mean=0, sd=1)
  if (d == 1) eps <- ifelse(X[, 1] > quantile(X[, 1], 3/4),
                            sample(c(a, b, c), size=1000, replace=TRUE, prob=rep(1/3, 3)),
                            rnorm(N, mean=0, sd=1))
  if (d > 1) {
    eps <- 0
    for (i in 1:d){
      eps <- eps + ifelse(X[, i] > quantile(X[, i], 3/4),
                          sample(c(a, b, c), size=1000, replace=TRUE, prob=rep(1/3, 3)),
                          rnorm(N, 0, 1))
    }
  }
  Y <- rowSums(X) + eps

  data <- as.data.frame(cbind(Y, X))
  residuals <- resid(lm(Y ~ ., data=data))

  list("data" = data, "resid" = residuals)
}
