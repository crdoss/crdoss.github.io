#' @title Generates "circle" data for a specific lasso simulation setup 
#'
#' @param N 
#' @param p 
#' @param d 
#' @param signal 
#'
#' @return
#' @export
#'
#' @importFrom MASS mvrnorm
#' 
#' @examples
generate_circle_data_lasso <-
function(N, p, d, signal=TRUE){
  Sigma <- 4 * diag(p)
  
  X <- abs(mvrnorm(N, mu=rep(5, p), Sigma))
  
  var <- 0
  if (d == 0) eps <- rnorm(N, mean=0, sd=1)
  if (d == 1) eps <- rnorm(N, mean=0, sd=pmin(20, 10/abs(X[, 1] - 5))) + 
    rnorm(N, mean=0, sd=0)
  if (d > 1){
      for (i in 1:d) var <- var + ifelse(X[,i] < 5, 
                                         pmax(1, X[, i]^2), 
                                         pmax(1, (10 - X[, i])^2))
    eps <- rnorm(N,0,var)
  }
  num <- ceiling(p/2)
  if (signal == TRUE) Y <- rowSums(X[, 1:num]) + eps
  if (signal == FALSE) Y <- rowSums(X[, (num + 1):p]) + eps
  
  data <- as.data.frame(cbind(Y,X))
  cv_lasso_fit <- cv.glmnet(X, Y, nfold=10, family="gaussian")
  lasso_fit <- glmnet(X, Y, family="gaussian", lambda=cv_lasso_fit$lambda.min)
  residuals <- Y - predict(lasso_fit, newx=X)
  
  residuals2 <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals, "resid2"=residuals2)
}
