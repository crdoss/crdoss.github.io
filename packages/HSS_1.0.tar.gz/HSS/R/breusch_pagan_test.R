#' @title Breusch Pagan Test 
breusch_pagan_test <-
function(X, resid, alpha=0.05) {
  sigma2 <- sum(resid^2) / length(resid)
  f <- resid^2 / sigma2 - 1
  pvals <- p.adjust(summary(lm(f~X))$coefficients[-1, 4], method="holm")
  
  which(pvals < alpha)
}
