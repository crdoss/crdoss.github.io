get_hyper_probs <-
function(c, S, n1, n2) {
    dhyper(S, n1, n2, S + c) * dhyper(1, n1 - S, n2 - c, 1)
}
