get_n_alpha_probs <-
function(alpha,n1,n2,odds,weight=TRUE) {
    ## alpha is significance level, n1 is size of comparison set, 
    ## and n2 is size of evaluation set
    ## 'weight' parameter: T --> Wallenius' noncentral hypergeometric
    ##                     F --> Standard hypergeometric w/alpha0
    
    if (weight==TRUE) {
        S <- floor(n1 * alpha)
        if (S >= n1) { 
            vec <- c(rep(0, n2), 1)
        } else vec <- sapply(c(0:n2), FUN=get_wnh_probs, S, n1, n2, odds)
    }
    
    if (weight == FALSE){
        ## alpha0 <- odds * alpha

        alpha0 <- alpha / odds  ## Evan correction 8 21 21.  Just incredible. 
        
        S <- floor(n1 * alpha0)
        if (S >= n1) { 
            vec <- c(rep(0, n2), 1)
        } else vec <- sapply(c(0:n2), FUN=get_hyper_probs, S, n1, n2)
    }
    
    vec
}
