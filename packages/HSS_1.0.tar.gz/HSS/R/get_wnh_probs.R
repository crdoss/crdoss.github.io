get_wnh_probs <-
function(c, S, n1, n2, odds) {
    dWNCHypergeo(S, n1, n2, S + c, odds) * dWNCHypergeo(1, n1 - S, n2 - c, 1, odds)
}
