make_rds_filename_from_experiment_parameters<-function(params, dir=NULL)
{
  final_file <- ""
  sep <- ""
  
  N <- params[['N']]
  p <- params[['p']]
  d <- params[['d']]
  k <- params[['k']]
  nsplit <- params[['nsplit']]
  B <- params[['B']]
  datatype <- switch(params[['data']], 'generate_fan_data' = "fan", "generate_circle_data"= "circle", "generate_null_data"= "null",
                     "generate_mixed_data" ="mixed", 'generate_fan_data_lasso' = "fanlasso", 
                     "generate_circle_data_lasso"= "circlelasso", "generate_mixed_data_lasso" ="mixedlasso", "generate_null_data_lasso"= "nulllasso",
                     "generate_three_point_data" ="threepoint", "generate_t_data" ="t")
  
  exp_num <- params[['exp_num']]
  
  if(!is.null(dir))
  {
    final_file<-dir
    sep <- "/"
  }
  
  final_file<-paste( final_file, paste(N, p, d, k, nsplit, B, datatype, exp_num, "results.rds", sep ="_" ), sep=sep)
  
  return(final_file)
  
}
