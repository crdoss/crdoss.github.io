# p and correction are included to provide compatibility with Charles' current code.
# can be removed with when everything is finalized
finalize_hss_results<-
  function(hss_results, hss_results_BS, critval, p=NULL, correction="bonferoni") {
    
    if(correction == "bonferoni")
    {
        ## get overall/final hss results
        critval_adj <- critval / p ##  Bonferroni rather than holm, for
        ##  simplicity right now
        cutoffs <- apply(hss_results_BS, c(1,3), quantile, 1 - critval_adj)
        ##cutoffs_agg1_v <- apply(hss_results_BS, c(1), quantile, 1 - crit_val_adj) 
        cutoffs_agg2_v <- apply(cutoffs, 1, mean) ## vector
        cutoffs_agg2 <- matrix(cutoffs_agg2_v,
                               nrow=length(cutoffs_agg2_v), ##nsims
                               ncol=p, byrow=FALSE)
        ##hss_final <- apply(hss_results_BS > cutoffs, 2, mean)
        ## hss_final <- apply(hss_results_BS > cutoffs_agg2, 2, mean)
        hss_final <- hss_results_BS > cutoffs## modification --charles

        ## the above line does not seem correct to me; i think hss_results_BS should be hss_results ! !
        
      
    }else{
      # get the empirical distribution--over all boostrap runs,i.e., under H_0--of the inclusion probabilities for each covariate (cols) in each simulation (rows)
      ecdf_matrix <- apply(hss_results_BS, c(1,3), ecdf)
      
      # get the (empirical) upper-tail p-value for for the observed inclusion probability of the hss_run--i.e., under H_1--for each covariate (cols) in each simulation (rows)
      inclusion_p_value <- mapply(function(x, x_ecdf){1-x_ecdf(x)}, hss_results, ecdf_matrix)
      inclusion_p_value_matrix <- matrix(inclusion_p_value, nrow = nrow(hss_results), ncol = ncol(hss_results), byrow = FALSE)
      
      # for each simulation (row), get the holms correction of the inclusion probability of each covariate (cols);
      # accounting for the muliple hypothesis testing, arising from testing multiple covariate
      corrected_inclusion_matrix <- t(apply(inclusion_p_value_matrix,1,p.adjust, method="holm"))
      
      # get the proportion ofsimulations that a covariate is an HRV--i.e., it's (corrected) inclusion probability is significant
        ##hss_final <- apply(corrected_inclusion_matrix < critval, 2, mean)
        ## hss_final <- corrected_inclusion_matrix < critval ## Charles 8/21/21 change
        hss_final <- corrected_inclusion_matrix <= critval ## Charles 8/26/21 change
    }
    
  hss_final
    
  }





