koenker_test <-
function(X, resid, alpha=0.05) {
  sigma2 <- sum(resid^2) / length(resid)
  w <- resid^2 - sigma2
  pvals <- p.adjust(summary(lm(w~X))$coefficients[-1, 4], method="holm")
  
  which(pvals < alpha)
}
