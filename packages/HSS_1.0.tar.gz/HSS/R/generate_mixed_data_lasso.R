#' @title  Generate "mixed" ("monotonic" and "non monotonic") heteroscedastic   data  for a specific lasso simulation
#'
#' @importFrom glmnet glmnet
#' @importFrom glmnet cv.glmnet
generate_mixed_data_lasso <-
function(N, p, d, signal=TRUE){
  if (d == 1) stop("Choose another d, d=1 not supported")
  Sigma <- 4 * diag(p)
  
  X <- abs(mvrnorm(N, mu=rep(5, p), Sigma))
  
  if (d == 0) eps <- rnorm(N, mean=0, sd=1)
  if (d == 2) {
    eps <- rnorm(N, mean=0, sd=1 + 10*X[, 1] + pmin(40/abs(X[, 2] - mean(X[, 2])), 80))
  }
  if (d > 2) {
    eps <- rnorm(N, mean=0, sd=1 + 5*rowSums(X[, 1:ceiling(d/2)]) +
                   pmin(40/abs(rowSums(X[, (ceiling(d/2)+1):d]) - 
                                 mean(X[, (ceiling(d/2)+1):d]) * floor(d/2)), 80))
  }
  num <- ceiling(p/2)
  if (signal == TRUE) Y <- rowSums(X[, 1:num]) + eps
  if (signal == FALSE) Y <- rowSums(X[, (num + 1):p]) + eps
  
  data <- as.data.frame(cbind(Y,X))
  cv_lasso_fit <- glmnet::cv.glmnet(X, Y, nfold=10, family="gaussian")
  lasso_fit <- glmnet::glmnet(X, Y, family="gaussian", lambda=cv_lasso_fit$lambda.min)
  residuals <- Y - predict(lasso_fit, newx=X) 
  
  residuals2 <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals, "resid2"=residuals2)
}
