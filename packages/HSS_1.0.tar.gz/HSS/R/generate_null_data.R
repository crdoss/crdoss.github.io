#' @title Generate non-heteroscedastic data
generate_null_data <-
function(N, p, d) {
  Sigma <- 4 * diag(p)
  
  X <- abs(mvrnorm(n=N, mu=rep(5, p), Sigma))
  
  eps <- rnorm(N, mean=0, sd=1)
  Y <- rowSums(X) + eps
  
  data <- as.data.frame(cbind(Y, X))
  residuals <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals)
}
