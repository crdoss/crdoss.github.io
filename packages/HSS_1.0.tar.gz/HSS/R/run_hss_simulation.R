#' @title   Implement a simulation for studying HSS
#'
#' @param N 
#' @param p 
#' @param d 
#' @param k 
#' @param data 
#' @param rho 
#' @param nsims 
#' @param nsplit 
#' @param B 
#' @param critval 
#' @param use_alphahat
#' @param alphagrid
#' @param how_compute_expecs Can be either "closedform" or "numeric".  Determines how E(N_alpha) and E(T_alpha) are computed.
#' @param q Parameter (power) defining the T_alpha statistic.  Commonly 2 or 1.  Can only do "closedform" expectation calculation if q is 2.
#'
#' @details
#' Right now, "weight" is set to FALSE in the get_n_alpha_probs call.
#' 
#' @return
#' @export
#'
#' @examples
run_hss_simulation <-  function(N, p, d, k, data, rho, nsims,
                                nsplit,
                                B,
                                critval=.1,
                                use_alphahat=TRUE,
                                alphagrid=FALSE,
                                how_compute_expecs=c("closedform", "numeric")[2],
                                q=2,
                                weight=FALSE) {
    ##    weight=FALSE; ## for get_n_alpha_probs
    results <- matrix(NA, nrow=nsims, ncol=p)
    results_BS <- array(NA, dim=c(nsims, B, p))
    ##, list("nsims",  "bootstraps", "covariates"))
    bp_results <- matrix(0, nrow=nsims, ncol=p)
    gq_results <- matrix(0, nrow=nsims, ncol=p)
    for (sim in 1:nsims) {
        inclusion_probs <- rep(0, p)
        
        ## Generate data
        data.suite <- get(data)(N, p, d)
        X <- data.suite$data[, -1]
        resid <- data.suite$resid
        
        for (split in 1:nsplit) {
            ## Get p-value matrix
            obj <- get_pvalue_matrix(X, resid, rho, k)
            probs <- obj$probs
            n.ref <- obj$n_ref
            n.ev <- obj$n_ev
            ref <- obj$ref
            ev <- obj$ev
            
            ## Perform HSS given a p-value matrix
            hrv_subset <- do_hss(probs, n.ref, n.ev,
                                 ref, ev, k,
                                 use_alphahat=use_alphahat,
                                 alphagrid=alphagrid,
                                 how_compute_expecs,
                                 q=q,
                                 weight=weight)$subset
            inclusion_probs[hrv_subset] <- inclusion_probs[hrv_subset] + 1
        }
        inclusion_probs <- inclusion_probs / nsplit
        results[sim, ] <- inclusion_probs

        ## do bootstrap (BS)
        for (bb in 1:B){
            ##added this missing line previously,
            ##then lost the fix:
            inclusion_probs <- rep(0, p)
            residB <- sample(resid, N, replace=TRUE)
            for (split in 1:nsplit){
                ## Get p-value matrix
                obj <- get_pvalue_matrix(X, residB, rho, k)
                probs <- obj$probs
                n.ref <- obj$n_ref
                n.ev <- obj$n_ev
                ref <- obj$ref
                ev <- obj$ev
                
                ## Perform HSS given a p-value matrix
                hrv_subset <- do_hss(probs, n.ref, n.ev,
                                     ref, ev, k,
                                     use_alphahat=use_alphahat,
                                     alphagrid=alphagrid,
                                     how_compute_expecs,
                                     q=q,
                                     weight=weight)$subset
                inclusion_probs[hrv_subset] <- inclusion_probs[hrv_subset] + 1
            }
            inclusion_probs <- inclusion_probs / nsplit
            results_BS[sim, bb, ] <- inclusion_probs
        }
        
        ## Alternative methods
        X <- as.matrix(X)
        Y <- data.suite$data[, 1]
        bp_subset <- breusch_pagan_test(X, resid, alpha = critval)
        bp_results[sim, bp_subset] <- 1 
        gq_subset <- goldfeld_quandt_test(Y, X, alpha= critval)
        gq_results[sim, gq_subset] <- 1 
    }


    hss_final  <- finalize_hss_results(results,
                                       results_BS,
                                       critval,
                                       p=p, ## unnecessary 
                                       correction="holm" ## not "bonferoni"
                                       )
    
    ## ## get overall/final hss results
    ## critval_adj <- critval / p ##  Bonferroni rather than holm, for
    ## ##  simplicity right now
    ## cutoffs <- apply(results_BS, c(1,3), quantile, 1 - critval_adj)
    ## ##cutoffs_agg1_v <- apply(out$hss_results_BS, c(1), quantile,crit_val_adj) 
    ## cutoffs_agg2_v <- apply(cutoffs, 1, mean) ## vector
    ## cutoffs_agg2 <- matrix(cutoffs_agg2_v,
    ##                        nrow=length(cutoffs_agg2_v), ##nsims
    ##                        ncol=p, byrow=FALSE)
    ## ## hss_final <- apply(results > cutoffs, 2, mean)
    ## ## hss_final <- apply(results > cutoffs_agg2, 2, mean)
    ## hss_final <- results > cutoffs
    
    list("hss_results"=results, "bp_results"=bp_results, "gq_results"=gq_results,
         "hss_results_BS"=results_BS
        ,"hss_final" = hss_final
         ) 
}
