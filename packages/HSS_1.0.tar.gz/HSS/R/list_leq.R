list_leq <-
function(x, alpha) {
    x <= alpha
}
