combine_simulation_results <-
  function(sim_results, p, B) {
    
    nexps <- length(sim_results)
  
    hss_results <- matrix(NA, nrow=nexps, ncol=p)
    hss_results_BS <- array(NA, dim=c(nexps, B, p))
    bp_results <- matrix(0, nrow=nexps, ncol=p)
    gq_results <- matrix(0, nrow=nexps, ncol=p)
    
    for(exp_num in 1:nexps)
    {
      exp <- sim_results[[exp_num]]
      hss_results[exp_num, ] <- exp$hss_result
      hss_results_BS[exp_num, , ] <- exp$hss_result_BS
      bp_results[exp_num, ] <- exp$bp_result
      gq_results[exp_num, ] <- exp$gq_result
    }
    
    list("hss_results"=hss_results, "bp_results"=bp_results, "gq_results"=gq_results,
         "hss_results_BS"=hss_results_BS)
}
