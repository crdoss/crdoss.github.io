#' @title   Implement a single experiment for studying HSS
#'
#' @param N 
#' @param p 
#' @param d 
#' @param k 
#' @param data 
#' @param rho 
#' @param nsplit 
#' @param B 
#' @param critval 
#' @param use_alphahat
#' @param alphagrid
#'
#' @return
#' @export
#'
#' @examples
hss_experiment <-
  function(N, p, d, k, data, rho,
           nsplit,
           B,
           critval=.1,
           use_alphahat=TRUE,
           alphagrid=FALSE,
           how_compute_expecs = c("closedform", "numeric")[2],
           q = 2,
           weight=FALSE) {
    
    #Ed: changed these to contain results for a single simulation run
    result <- NULL
    result_BS <- matrix(NA, nrow=B, ncol=p)
    bp_result <- rep(0,p)
    gq_result <- rep(0,p)
    inclusion_count <- rep(0, p)
    
    ## Generate data
    data.suite <- get(data)(N, p, d)
    X <- data.suite$data[, -1]
    resid <- data.suite$resid
    
    for (split in 1:nsplit) {
      ## Get p-value matrix
      obj <- get_pvalue_matrix(X, resid, rho, k)
      probs <- obj$probs
      n.ref <- obj$n_ref
      n.ev <- obj$n_ev
      ref <- obj$ref
      ev <- obj$ev
      
      ## Perform HSS given a p-value matrix
      hrv_subset <- do_hss(probs, n.ref, n.ev,
                           ref, ev, k,
                           use_alphahat=use_alphahat,
                           alphagrid=alphagrid,
                           how_compute_expecs=how_compute_expecs,
                           q=q,
                           weight=weight)$subset
      inclusion_count[hrv_subset] <- inclusion_count[hrv_subset] + 1
    }
    result <- inclusion_count / nsplit
    
    ## do bootstrap (BS)
    for (bb in 1:B){
      
      inclusion_count <- rep(0, p) ## had left this line out 
      residB <- sample(resid, N, replace=TRUE)
      for (split in 1:nsplit){
        ## Get p-value matrix
        obj <- get_pvalue_matrix(X, residB, rho, k)
        probs <- obj$probs
        n.ref <- obj$n_ref
        n.ev <- obj$n_ev
        ref <- obj$ref
        ev <- obj$ev
        
        ## Perform HSS given a p-value matrix
        hrv_subset <- do_hss(probs, n.ref, n.ev, ref, ev, k)$subset
        inclusion_count[hrv_subset] <- inclusion_count[hrv_subset] + 1
      }
      result_BS[bb, ] <- inclusion_count / nsplit
    }
    
    ## Alternative methods
    X <- as.matrix(X)
    Y <- data.suite$data[, 1]
    bp_subset <- breusch_pagan_test(X, resid, alpha=critval)
    bp_result[bp_subset] <- 1 
    gq_subset <- goldfeld_quandt_test(Y, X, alpha=critval)
    gq_result[gq_subset] <- 1 
    
    exp_result <- list("hss_result"=result, "bp_result"=bp_result, "gq_result"=gq_result,
                       "hss_result_BS"=result_BS)
    
    return(exp_result)
  }