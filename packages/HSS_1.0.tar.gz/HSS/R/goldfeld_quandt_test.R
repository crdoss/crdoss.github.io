goldfeld_quandt_test <-
function(Y, X, alpha=0.05) {
  pvals <- vector()
  for (i in 1:ncol(X)) {
    pvals[i] <- gqtest(Y ~ X[, i], alternative="two.sided", order.by=X[, i])$p.value
  }
  pvals <- p.adjust(pvals, method="holm")
  
  which(pvals < alpha)
}
