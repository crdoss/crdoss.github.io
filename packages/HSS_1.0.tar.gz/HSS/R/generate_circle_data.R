#' @title Generates "circle" heteroscedastic data (see paper)
#'
#' @param N 
#' @param p 
#' @param d 
#'
#' @return
#' @export
#'
#' @importFrom MASS mvrnorm
#' 
#'
#' @examples
generate_circle_data <- function(N, p, d) {
  Sigma <- 4 * diag(p)
  
  X <- abs(MASS::mvrnorm(n=N, mu=rep(5, p), Sigma))
  
  var <- 0
  if (d == 0) eps <- rnorm(N, mean=0, sd=1)
  if (d == 1) eps <- rnorm(N, mean=0, sd=pmin(20, 10/abs(X[, 1] - 5))) + rnorm(N, 0, 0)
  if (d > 1) {
    for (i in 1:d) {
      var <- var + ifelse(X[, i] < 5, pmax(1, X[, i]^2), pmax(1, (10 - X[, i])^2))
    }
    eps <- rnorm(N, mean=0, sd=var)
  }
  
  Y <- rowSums(X) + eps
  
  data <- as.data.frame(cbind(Y, X))
  residuals <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals)
}
