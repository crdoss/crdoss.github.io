#' @title   Implement a simulation for studying HSS
#'
#' @param N 
#' @param p 
#' @param d 
#' @param k 
#' @param data 
#' @param rho 
#' @param nsims 
#' @param nsplit 
#' @param B 
#' @param critval 
#' @param use_alphahat
#' @param alphagrid
#'
#' @return
#' @export
#'
#' @examples
run_hss_simulation_new <-
  function(N, p, d, k, data, rho, nsims,
           nsplit,
           B,
           critval=.1,
           use_alphahat=TRUE,
           alphagrid=FALSE,
           num_cores=1) {
    `%do_type%` <- `%do%`
    if(num_cores > 1)
    {
      `%do_type%` <- `%dopar%`
      registerDoParallel(cores=num_cores)
    }
    
    exp_results<-foreach(sim=1:nsims) %do_type%{
    #for (sim in 1:nsims){
    
      hss_experiment(N, p, d, k, data, rho, nsims,
                     nsplit, B, critval,use_alphahat,
                     alphagrid)
    }
    
    sim_results <-combine_simulation_results(exp_results, p, B)
    hss_final <- finalize_hss_results(sim_results$hss_results, sim_results$hss_results_BS, critval, p=p, correction="holms")
   
    sim_results[["hss_final"]] <- hss_final
    
    sim_results
}
