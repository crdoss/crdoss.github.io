#' @title  Compute expectations of $N_\alpha$, $T_\alpha$

## Weight argument cannot be used if using "closedform."


## get_expected_sum1 is Evan's original function
## get_expected_sum2 is new code

## Not sure the best way to implement the transition to the new code, since
## we are changing from "q=1" to "q=2".  For now I set get_expected_sum to
## get_expected_sum2 at the bottom; although this could be a poor idea
## because it means get_expected sum could take different arguments.  As long
## as the extra arguments are at the end and have defaults set, should be OK.  Need to be able to test get_expected_sum2 on its own.


## Note: Evan's default code has weight in get_n_alpha_probs set to TRUE.  This may

get_expected_sum1 <-
    function(alpha, n_ref, n_ev, p, odds) {
        k <- length(n_ref) - 1 ## find number of subgroups
        n2 <- n_ref[2:(k+1)] - n_ev[1:k] ## get sizes of each subgroup
        n1 <- max(n_ev) - n2 ## get sizes of each comparison set
        
        prob_vecs <- list() ## initialize list for probabilities
        for (i in 1:k) {
            prob_vecs[[i]] <- get_n_alpha_probs(alpha, n1[i], n2[i], odds)
        }
        
        N <- lengths(prob_vecs) - 1 ## subgroup sizes
        expected_N_alpha <- vector()
        expected_T <- vector()
        for (i in 1:k) {
            ## Find probability that N_alpha(P_jk) = c, for c=0,...,n1
            prob_vecs[[i]] <- get_n_alpha_probs(alpha, n1[i], n2[i], odds)
            
            ## Calculate E(N_alpha) and E(T_alpha)
            expected_N_alpha[i] <- sum(prob_vecs[[i]] * c(0:N[i]))
            expected_T[i] <- sum(abs(0:N[i] - expected_N_alpha[i]) * 
                                 prob_vecs[[i]][1:(N[i]+1)])
        }

        ## matrix with expected N_alpha for each subgroup
        N_mat <- matrix(rep(expected_N_alpha, p), nrow=k) 
        ## sum up T_alpha over k
        T_sum <- sum(expected_T) 
        
        list("expected_T"=T_sum, "expected_N"=N_mat)
    }


## if how_compute_expecs == "closedform" then must have q==2

## here we do the q==2.
get_expected_sum2 <-    function(alpha, n_ref, n_ev, p,
                                odds
                               ,how_compute_expecs = c("closedform", "numeric")[2]
                               ,q = 2
                               ,weight = FALSE
                                ) {
    stopifnot(0 < q && q < Inf)
    ##    q <- 2; ## def'n T

    k <- length(n_ref) - 1 ## find number of subgroups
    n2 <- n_ref[2:(k+1)] - n_ev[1:k] ## get sizes of each subgroup
    n1 <- max(n_ev) - n2 ## get sizes of each comparison set
    expected_N_alpha <- vector()
    expected_T <- vector()
    if (how_compute_expecs == "numeric"){
        
        prob_vecs <- list() ## initialize list for probabilities
        for (i in 1:k) {
            prob_vecs[[i]] <- get_n_alpha_probs(alpha, n1[i], n2[i],
                                                odds, weight)
        }
        
        N <- lengths(prob_vecs) - 1 ## subgroup sizes
        for (i in 1:k) {
            ## Find probability that N_alpha(P_jk) = c, for c=0,...,n1
            prob_vecs[[i]] <- get_n_alpha_probs(alpha, n1[i], n2[i],
                                                odds, weight)
            
            ## Calculate E(N_alpha) and E(T_alpha)
            expected_N_alpha[i] <- sum(prob_vecs[[i]] * c(0:N[i]))
            expected_T[i] <- sum(abs(0:N[i] - expected_N_alpha[i])^q * 
                                 prob_vecs[[i]][1:(N[i]+1)])
        }

        ## ## matrix with expected N_alpha for each subgroup
        ## N_mat <- matrix(rep(expected_N_alpha, p), nrow=k) 
        ## ## sum up T_alpha over k
        ## T_sum <- sum(expected_T)
    }
    else if (how_compute_expecs == "closedform"){
        stopifnot(q==2)
        stopifnot(weight==FALSE)

        ## alpha0  <- odds * alpha

        alpha0  <- alpha / odds ## Evan correction 8 21 21.  Just incredible. 
        
        for (i in 1:k){
            ##expected_N_alpha[i] <- n2[i] * alpha0

            expected_N_alpha[i] <- n2[i] *
             ((floor(n1[i] * alpha0) + 1) / (n1[i] + 1))## approx n2[i] * alpha0
            expected_T[i] <- n2[i] *
                (floor(alpha0*n1[i]) +1) * (n1[i] - floor(alpha0*n1[i])) *
                (n1[i]+n2[i]+1) /
                ( (n1[i]+1)^2 * (n1[i]+2) );
            
        }

        ## ## preliminary hack
        ## ## for timing purposes only !
        ## tmp <- rep(1, times=k)
        ## N_mat <- matrix(rep(tmp, p), nrow=k);
        ## T_sum <- 1;

        
    }
    else stop(paste0("Must have how_compute_expecs",
                     " set to either closedform or numeric"));

    ## matrix with expected N_alpha for each subgroup
    N_mat <- matrix(rep(expected_N_alpha, p), nrow=k) 
    ## sum up T_alpha over k
    T_sum <- sum(expected_T)
    
    list("expected_T"=T_sum, "expected_N"=N_mat)
}

get_expected_sum <- get_expected_sum2
