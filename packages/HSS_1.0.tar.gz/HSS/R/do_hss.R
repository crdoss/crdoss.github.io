#' @title do_hss implements the heteroscedastic subset scan (HSS).
#'
#' @param pvals matrix ("n x p")
#' @param n.ref
#' @param n.ev
#' @param ref
#' @param ev
#' @param k
#' @param  use_alphahat TRUE/FALSE: for whether  to (TRUE) or not  to (FALSE)
#'     "condition on alphahat" (alphahat is known as "alpha_0" in the paper).
#' @param alphagrid The procedure searches over all alpha in (0,1].  This can
#'     be done  exactly (if use_alphagrid  is nonnumeric e.g. FALSE  or NULL)
#'     (causing n*p  operations); otherwise if  alphagrid is a  single number
#'     then  a  uniformly spaced  grid  of  that  length  over (0,1] will be  used,  and
#'     otherwise a specific grid can be passed in.
#' @param how_compute_expecs Can be either "closedform" or "numeric".  Determines how E(N_alpha) and E(T_alpha) are computed.
#'
#' @return
#' @export
#'
#' @importFrom BiasedUrn dWNCHypergeo
#'
#' @examples
#'
#'


## erorr error call getexpectedsum2 (q=2) instead of old one

## need to change  the call to getexpected sum
## then need also change the definition of the statistic in the code

## the simulation function should change
## teh call to d0 hss  should change

do_hss <- function(pvals, n.ref, n.ev,
             ref, ev, k,
             use_alphahat=TRUE,
             alphagrid=FALSE,
             how_compute_expecs = c("closedform", "numeric")[2]
            ,q = 2
            ,weight=FALSE
             ) {
    stopifnot(0 < q && q < Inf)
    if (how_compute_expecs == "closedform") stopifnot(weight==FALSE)
    ##    if (how_compute_expecs == "closedform") stopifnot(q==2)






    overall_max <- 0 ## initialize max(F(S))
    n <- nrow(pvals) ## size of evaluation set
    p <- ncol(pvals) ## number of covariates


    ## set list of alpha levels to scan over
    if (is.numeric(alphagrid)){
        if (length(alphagrid)==1){
            if (round(alphagrid) != alphagrid || alphagrid < 1)
                stop("Error in alphagrid: need an integer >= 1.")
            alphas <- (1:alphagrid) / alphagrid;
        }
        else alphas <- alphagrid
    }
    else
        alphas <- unique(unlist(pvals))

    ## List of p-values by subgroup
    pvals_by_group <- list()
    for (K in 1:k) pvals_by_group[[K]] <- pvals[(n.ev[K]+1):n.ev[K+1], ]

    ## For every alpha value, perform the scan
    for (alpha in alphas) {
        ## Count the number of alpha-level significant p-values in each subgroup of p-values
        num_sig <- lapply(pvals_by_group, FUN=list_leq, alpha)
        N_alpha <- matrix(unlist(lapply(num_sig, FUN=colSums)), byrow=TRUE, nrow=k)

        ## Calculate weights based on entire reference and evaluation sets
        alpha_pct <- quantile(abs(ref[, 1]), probs=1-alpha, type=1)
        odds <- ifelse(mean(abs(ref[, 1]) > alpha_pct) == 0 |
                       mean(abs(ev[, 1]) > alpha_pct) == 0,
                       1, mean(abs(ref[, 1]) > alpha_pct) / mean(abs(ev[, 1]) > alpha_pct))

        if (!use_alphahat) odds <- 1;

        ## ######### Calculate E(N_alpha | alpha0) and ...
        ##
        expectations <- get_expected_sum(alpha, n.ref, n.ev, p, odds,
                                         how_compute_expecs
                                        ,q
                                        ,weight=weight
                                         )

        ## expectations2 <- get_expected_sum2(alpha, n.ref, n.ev, p, odds,
        ##                                    "numeric"
        ##                                   ,q=1
        ##                                   ,weight=TRUE
        ##                                    )

        ## print("expectations")
        ## print(expectations)

        ## print("expectations2")
        ## print(expectations2)

        ## if (sum(abs(expectations$expected_T-expectations2$expected_T)) > 1e05){
        ##     print("error in sum abs expectations difference. The value of sum(abs(expectations-expectations2))  is:")
        ##     print(sum(abs(expectations-expectations2)))
        ##     print(paste("The value of how_compute_expecs is ", how_compute_expecs,
        ##                 "and q is", q,
        ##                 "and weight is", weight))
        ## }



        exp_N <- expectations$expected_N

        ## Find T_alpha(X_j) values for j=1,...,p
        T_alpha_init <- colSums(abs(N_alpha - exp_N)^q)
        todo <- order(T_alpha_init, decreasing=TRUE)
        ## Get T_alpha(S) for the p subsets suggested by the priority function
        T_alpha <- cumsum(sort(T_alpha_init, decreasing=TRUE))

        ## Get vector of E(T(S)) for S of sizes 1,2,...,p
        exp_T <- expectations$expected_T * c(1:p)
        ## Calculate F(S) for the p subsets suggested by the priority function
        f_stat <- ifelse(T_alpha > exp_T & exp_T > 0, (T_alpha - exp_T)^2 / exp_T,
                         0)
        ## Record the largest F-statistic for this alpha
        max_over_S <- max(f_stat)

        ## If this F-stat is the overall maximum, update values
        if (max_over_S >= overall_max) {
            overall_max <- max_over_S ## update max statistic
            max_alpha <- alpha ## update alpha
            max_S <- todo[1:which.max(f_stat)] ## update S*
        }
    }

    list("F_stat" = overall_max, "max_alpha" = max_alpha, "subset" = max_S)
}


