get_n_beat <-
function(x, y) {
    sum(x > y)
}
