glejser_test <-
function(X, resid, alpha=0.05) {
  ab_resid <- abs(resid)
  pvals <- p.adjust(summary(lm(ab_resid~X))$coefficients[-1, 4], method="holm")
  
  which(pvals < alpha)
}
