get_experiment_parameters_from_rds_filename<-function(filename)
{
  path_split <- strsplit(filename,"/")[[1]]
  final_filename <- path_split[length(path_split)]
  
  split <- strsplit(final_filename, "_")[[1]]
  
  N <- as.integer(split[1])
  p <- as.integer(split[2])
  d <- as.integer(split[3])
  k <- as.integer(split[4])
  nsplit <- as.integer(split[5])
  B <- as.integer(split[6])
  datatype <- switch(split[7], 'fan' = "generate_fan_data", "circle"= "generate_circle_data", 
                     "mixed" ="generate_mixed_data", "null"= "generate_null_data",'fanlasso' = "generate_fan_data_lasso", 
                     "circlelasso"= "generate_circle_data_lasso", "mixedlasso" ="generate_mixed_data_lasso", "nulllasso"= "generate_null_data_lasso",
                     "threepoint" ="generate_three_point_data",
                     "t" ="generate_t_data")
  exp_num <- as.integer(split[8])
  
  params<-list(N = N, p = p, d = d, k = k, nsplit = nsplit, B = B, data = datatype, exp_num = exp_num)
  
  return(params)
}