#' @title Generate non heteroscedastic data (for a lasso simulation)
generate_null_data_lasso <-
function(N, p, d, signal=TRUE){
  Sigma <- 4 * diag(p)
  
  X <- abs(mvrnorm(N, rep(5, p), Sigma))
  
  eps <- rnorm(N, 0, 1)
  num <- ceiling(p/2)
  if (signal == TRUE) Y <- rowSums(X[, 1:num]) + eps
  if (signal == FALSE) Y <- rowSums(X[, (num + 1):p]) + eps
  
  data <- as.data.frame(cbind(Y,X))
  cv_lasso_fit <- cv.glmnet(X, Y, nfold=10, family="gaussian")
  lasso_fit <- glmnet(X, Y, family="gaussian", lambda=cv_lasso_fit$lambda.min)
  residuals <- Y - predict(lasso_fit, newx=X)
  
  residuals2 <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals, "resid2"=residuals2)
}
