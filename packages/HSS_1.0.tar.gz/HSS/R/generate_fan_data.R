#' @title Generates "fan" data (see paper)
generate_fan_data <-
    function(N, p, d) {
  Sigma <- 4 * diag(p)
  
  X <- abs(mvrnorm(n=N, mu=rep(5, p), Sigma))
  
  if (d == 0) eps <- rnorm(N, mean=0, sd=1)
  if (d == 1) eps <- rnorm(N, mean=0, sd=1 + X[, 1])
  if (d > 1)  eps <- rnorm(N, mean=0, sd=1 + rowSums(X[, 1:d]))
  Y <- rowSums(X) + eps
  
  data <- as.data.frame(cbind(Y, X))
  residuals <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals)
}
