generate_t_data <-
function(N, p, d){
  Sigma <- 4 * diag(p)
  
  X <- abs(mvrnorm(N, mu=rep(5,p), Sigma))
  
  if (d == 0) eps <- rnorm(N, 0, sqrt(5/3))
  if (d == 1) eps <- ifelse(X[,1] > quantile(X[, 1], 3/4), 
                            rt(N, df=5), 
                            rnorm(N, mean=0, sd=sqrt(5/3)))
  if (d > 1) {
    eps <- 0
    for (i in 1:d){
      eps <- eps + ifelse(X[, i] > quantile(X[, i], 3/4), 
                          rt(N, df=5), 
                          rnorm(N, mean=0, sd=sqrt(5/3)))
    }
  }
  Y <- rowSums(X) + eps
  
  data <- as.data.frame(cbind(Y, X))
  residuals <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals)
}
