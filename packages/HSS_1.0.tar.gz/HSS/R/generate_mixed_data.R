#' @title  Generate "mixed" ("monotonic" and "non monotonic") heteroscedastic  data 
generate_mixed_data <-
function(N, p, d) {
  if (d == 1) stop("Choose another d, d=1 not supported")
  Sigma <- 4 * diag(p)
  
  X <- abs(mvrnorm(n=N, mu=rep(5, p), Sigma))
  
  var <- 0
  if (d == 0) eps <- rnorm(N, mean=0, sd=1)
  if (d == 2) {
    var <- 5 * X[, 1] + 
      ifelse(X[, 2] < 5, pmax(1, X[, 2]^2), pmax(1, (10 - X[, 2])^2))
    eps <- rnorm(N, mean=0, sd=var)
  }
  if (d > 2) {
    var <- 2 * rowSums(X[, 1:ceiling(d/2)])
    for (i in (ceiling(d/2)+1):d) {
      var <- var + ifelse(X[, i] < 5, 
                          pmax(1, X[, i]^2), 
                          pmax(1, (10 - X[, i])^2))
    }
    eps <- rnorm(N, 0, var)
  }
  Y <- rowSums(X) + eps
  
  data <- as.data.frame(cbind(Y, X))
  residuals <- resid(lm(Y ~ ., data=data))
  
  list("data" = data, "resid" = residuals)
}
