#' HSS: Heteroscedasticity Subset Scan
#'
#'
#' Scan   the   vector   of   residuals   from   a   regression   to   detect
#' heteroscedasticity,  and in  fact to  find the  variables causing  it, the
#' so-called   Heteroscedastically  Relevant   Variables.    These  are   the
#' covariates with which the error variance (or distribution) changes.  Here,
#' "heteroscedasticity" includes  "weak heteroscedasticity" which  includes a
#' non-constant  error  distribution  (i.e.,   variation  beyond  the  second
#' moment). A package for computing an estimator in the problem of univariate
#' Unlinked Monotone Regression. See Balabdaoui, Doss, and Durot (2020+).
#'
#' @section UMR functions:
#'
#' The main function is do_hss()  which implements the Heteroscedastic Subset
#' Scan procedure.  The  function run_hss_simulation() implements simulations
#' based on the procedure.
#'
#' @docType package
#'
#' @name HSS
NULL
