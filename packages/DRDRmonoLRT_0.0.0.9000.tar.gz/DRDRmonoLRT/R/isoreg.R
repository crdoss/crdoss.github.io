## wrapper around stats::isoreg()

## Already export monoreg. The isoreg function returns different things (includuing knot locations). May be somewhat confusing to export both.


#' @title  Monotonic regression
#' @param xx vector of nn covariate observations (univariate).  Not currently required to be sorted.  Should be unique.  (For nonuniqueness we need an implementation with weights, which are not included here.)
#' @param yy vector of nn response observations (univariate)
#' @param type String "isotonic" (default) for increasing (non-decreasing) or "antitonic" for decreasing (non-increasing) regression
#'
#' @return A list.
#' @export
#'
#' @details Returns a list.  A wrapper for stats::isoreg.  Hence, chose
#'   not to change the name, although this could lead to confusing errors at
#'   times. Note that this package also exports a wrapper for fdrtool::monoreg.
#'  The two functions return different things so both are currently used although only one is really needed.
#' Returns a list with the same quantities as stats:isoreg, except that xx is always sorted,  plus  S the sum of squared errors (not divided by sample size, $L gives $S over sample size. Unlike stats::isoreg, we allow a type arg so that antitonic regression is handled internally.
#'
#
#'
#' @examples
#'
#' nn <- 100
#' xx <- sort(runif(nn, 0,1))
#' ff <- function(xx){-xx}
#' yy <- ff(xx) + rnorm(nn, sd=.5)
#' out <- isoreg(xx=xx,yy=yy, type="antitonic")


isoreg <- function(xx, yy,
                   type="isotonic"){
  nn <- length(xx)
  if (nn != length(yy)) stop("Require length(xx) == length(yy).")
  if (anyNA(xx) || anyNA(yy))  stop("missing values not allowed")
  isOrd <- !is.unsorted(xx, strictly = TRUE)
  if (!isOrd){
    oo <- order(xx,-yy)
    xx <- xx[oo]
    yy <- yy[oo]
  }
  if (length(unique(xx))<nn) stop("Require xx to have unique entries.")
  if (type == "antitonic") ## if isotonic, do default behavior
    yy = - yy
  ## actual work
  out <- stats::isoreg(xx, yy)
  ## setup return value
  S <- sum((out$yf - out$y)^2)
  if (type=="antitonic"){
    out$yf = - out$yf
    out$y = -out$y
    out$yc = -out$yc
  }
  ## # new
  out$S = S
  out$L = S / nn
  ## return
  out
}

