## Get pseudo outcomes


#' @title Get pseudo outcomes based on sample splitting.
#' @param yy,aa,ll data: yy is outcome, aa is treatment (a continuous
#'   variable) and ll is the covariate/confounders.

#' @param fit_nuisances_subset Function for fitting the nuisance
#'   parameters. See xxx.
#'
#' @param KK Number of splits. Currently only 1 (no splitting) or 2 is
#'   implemented. NOTE: there is no sanity checking right now that the
#'   LRstat_distn matches.

#'
#' @return matrix with n (sample size) rows and 2 columns, first column is pseudo outcomes and second column is index (integer) of fold.
#'
#' @export
#'
#' @details Computes pseudo outcomes.
#'




get_pseudos_SS <- function( yy, aa, ll,
                           KK = 2,
                           fit_nuisances_subset){
  returntype = "ignorefornow"
  n_SS <- length(aa);
  pseudo.out <- fold_labels <- vector("numeric", length=n_SS)
  lldf <- as.data.frame(ll); ## compatibility with current implementation of fit_nuisances functions
  ##  partitions<-split(1:n_SS,sample(rep(1:KK,times=n_SS/KK)))
  partitions<-split(1:n_SS,sample(rep(1:KK,length=n_SS))) ## allows uneven sizes...


  if (returntype == "all")
    nuisances <- list()

  LRstatsScaled = vector(length=KK)
  for(i in 1:KK){
    fold_labels[partitions[[i]]] <- i
    ##     fnuis <- fit_nuisances_SL_subset(yy,aa,ll,partitions[[i]],stabweight.low = .1)
    fnuis <- fit_nuisances_subset(yy,aa,lldf, subset=partitions[[i]])
    if (returntype=="all") { ## sanity checking
      nuisances[[i]] <- fnuis
    }
    pseudo.out[partitions[[i]]] <- (fnuis$yy - fnuis$muhat) * fnuis$varpihat / fnuis$pihat + fnuis$mhat
  }
  return(cbind(pseudo.out=pseudo.out, fold=fold_labels))
}

