## Causal monotonic/isotonic regression likelihood ratio (residual sum of squares) based confidence interval with sample splitting


#' @title Likelihood Ratio (i.e., residual sum of squares) Confidence Interval (CI) for r(x_0), Assuming r is monotone increasing or decreasing, where r is the dose-response (treatment effect) curve for a continuous treatment variable (aa) with measured confounders ll.
#' @param yy,aa,ll data: yy is outcome, aa is treatment (a continuous variable) and ll is the covariate/confounders.
#' @param x0 Function value at which to construct the CI
#' @param alpha Level for CI.
#' @param fit_nuisances_subset Function for fitting the nuisance parameters. See xxx.
#' @param beta0 The flatness. Currently, values are: "0.01" "0.2" "0.4" "0.6" "0.8" "1" "2" "5"
#' @param KK Number of splits. Currently only 2 is implemented. NOTE: there is no sanity checking right now that the LRstat_distn matches.
#' @param CIprec Tolerance parameter for computing boundary of CI.
#'
#' @param type String "isotonic" (default) for increasing (non-decreasing) or "antitonic" for decreasing (non-increasing) regression
#' @param verb unused (verbosity argument, real number >= 0).
#'
#' @return Vector of length 2 giving the CI.
#'
#'
#' @export
#'
#' @details Implements likelihood ratio / rss test based on possible sample
#'   splitting (SS). Currently requires large 1gb object storing the
#'   numerically convolved limit distribution. Almost identical to monoreg_CI
#'   essentially, except uses _SS test and so also generates pseudo outcomes
#'   internally.
#'


# param returntype Can be "test" or "statistic".  If the former then a 0 or 1 is
#'   returned (the test result); if the latter, the actual ( -2 log likelihood
#'   ratio, i.e. RSS) test statistic is returned.
#'

# return If returntype[1] == "test" then returns TRUE or FALSE.  If
#'   returntype[1]=="statistics" then returns the residual sum of squares
#'   statistic.

causal_monoreg_CI_SS <-    function(x0,
                                    yy, aa, ll,
                                    KK = 2,
                                    beta0 = c("0.01", "0.2", "0.4", "0.6", "0.8", "1", "2", "5"),
                                    fit_nuisances_subset,
                                    alpha=.05,
                                    ## LRstat_distn = NULL,
                                    CIprec=1e-4,
                                    type="isotonic",
                                    verb=0
                                    ##returntype = c("test", "statistic", "statistic-scaled", "all")
                                    ){
  ## if (KK==1) {
  ##   print("Unfortunately, KK==1 is not currently implemented in the _SS version. Use non-SS function. KK must be 2.")
  ##         stop()
  ## }
  ## stopifnot(KK==2)
  myLRstat_distn_quantiles <- DRDRmonoLRTobject::LRstat_distn_SS_mat[KK, , beta0]
  ##  myLRstat_distn = DRDRmonoLRTobject::LRstat_distn_SS_list[[beta0]][[KK]] ## data object of package; large (~1gb)/ slow!
  ##  QQ <- myLRstat_distn@q(1-alpha)
  QQ =   quantile(myLRstat_distn_quantiles, probs = 1 - alpha)
  n_SS <- length(aa);
  lldf <- as.data.frame(ll); ## compatibility with current implementation of fit_nuisances functions
  ##  partitions<-split(1:n_SS,sample(rep(1:KK,times=n_SS/KK)))
  partitions<-split(1:n_SS,sample(rep(1:KK,length=n_SS))) ## allows uneven sizes...
  pp <- length(alpha)


  pseudo.out<-vector("numeric", length=n_SS)
#  if (returntype == "all")
#    nuisances <- list()


  for(i in 1:KK){
    ##     fnuis <- fit_nuisances_SL_subset(yy,aa,ll,partitions[[i]],stabweight.low = .1)
    fnuis <- fit_nuisances_subset(yy,aa,lldf, subset=partitions[[i]])
    ## if (returntype=="all") { ## sanity checking
    ##   nuisances[[i]] <- fnuis
    ## }
    pseudo.out[partitions[[i]]] <- (fnuis$yy - fnuis$muhat) * fnuis$varpihat / fnuis$pihat + fnuis$mhat
  }



  myLRtest <- function(yy0){
    LRstatsScaled = vector(length=KK)
    for(i in 1:KK){
##      fnuis <- fit_nuisances_subset(yy,aa,lldf, subset=partitions[[i]])
      LRstatsScaled[i] <-      monoreg_LRtest(x0=x0,
                                              y0_hyp=yy0,
                                              xx=aa[partitions[[i]]],
                                              yy=pseudo.out[partitions[[i]]],
                                              sigmasq=NULL,
                                              ## LRstat_distn = myLRstat_distn, ## already selected from object package
                                              alpha=alpha,
                                              type=type,
                                              returntype="statistic-scaled",
                                              ##returntype="statistic",
                                              verb=verb)
    }
    avgLRstat = mean(LRstatsScaled)
    ##    QQ <- myLRstat_distn@q(1-alpha)
    return(avgLRstat>QQ)
  }
  y.sort <- sort(pseudo.out)

  rhats <- vector(length=KK)
  for (i in 1:KK){
    MLE.UC <- monoreg(xx=aa[partitions[[i]]],
                      yy=pseudo.out[partitions[[i]]],
                      type=type, verb=verb)
    MLE.UC.f <- approxfun(MLE.UC$xx, MLE.UC$ff)
    rhats[i] <- MLE.UC.f(x0)
  }
  rhat <- mean(rhats)
  if (verb>1) print(paste("rhat:", rhat))

  if (0){ ## I guess I am leaving this off for now ... Note it behaves somewhat differently for sample splitting than non-. ...
    if (any(myLRtest(rhat))) ## sanity check
      stop(paste("LR test rejecting unconstrained MLE (at some alpha);",
                 "perhaps alpha is too close to 1."))
  }

  {## now get outer limits of the interval
    supp.len <- tail(y.sort,1)-y.sort[1]
    L.start <- y.sort[1] ## L.start, R.start are starting values for left,right endpoints of interval.
    R.start <- tail(y.sort,1) ##they usually are x[1], x[length(x)].
    ## arbitrary: linearly increase length until exclude endpoint
    count.check <- 0
    while (any(!myLRtest(L.start)) && count.check <= 20){
      L.start <- L.start - supp.len
      count.check <- count.check+1
    }
    if (count.check >=21)
      warning("count.check >= 21, Left: issue with initializing search endpoints.")
    count.check <- 0
    while (any(!myLRtest(R.start)) && count.check <= 20){
      R.start <- R.start + supp.len
      count.check <- count.check+1
    }
    if (count.check >=21)
      warning("count.check >= 21, Right: issue with initializing search endpoints.")
  }



  ## now use binary search starting from L.start, R.start for alpha[1]
  ## (note that all tests rejects L.start and R.start).
  ## For all alphas, keep track of L and R until they disagree with L[ii] and R[ii],
  ## then pick up where you left off..

  Lpts <- vector("numeric",length=pp)
  Rpts <- vector("numeric",length=pp)
  L <- rep(L.start, length=pp)
  R <- rep(rhat, length=pp)
  for (ii in 1:pp){
    while(R[ii]-L[ii] > CIprec){ ##R is in, L is out
      mid <- (R[ii]+L[ii])/2 ## mid for all indices still matching ii'th
      currRes <- !myLRtest(mid)
      match.ii <- (currRes==currRes[ii]) ## keep record for indices matching current one
      R[currRes & match.ii  &  ((1:pp)>= ii)] <- mid
      L[(!currRes) & match.ii  &  ((1:pp)>= ii)] <- mid
    }
    Lpts[ii] <- L[ii]
  }




  ## Do right side
  L <- rep(rhat, length=pp)
  R <- rep(R.start, length=pp)
  for (ii in 1:pp){
    while (R[ii]-L[ii] > CIprec){ ## R is out L is in
      mid <- (R[ii]+L[ii])/2
      currRes <- !myLRtest(mid)
      match.ii <- (currRes==currRes[ii])
      L[currRes & match.ii & ((1:pp) >=ii)] <- mid
      R[(!currRes) & match.ii & ((1:pp) >=ii)] <- mid
    }
    Rpts[ii] <- R[ii]
  }

  ##return(c(Lpt,Rpt))
  return(cbind(Lpts,Rpts))
}

