## many other functions exist in the CRAN sphere with this same name




#' @title  Monotonic regression
#' @param xx vector of nn covariate observations (univariate).  Not currently required to be sorted.  Should be unique.  (For nonuniqueness we need an implementation with weights, which are not included here.)
#' @param yy vector of nn response observations (univariate)
#' @param type String "isotonic" (default) for increasing (non-decreasing) or "antitonic" for decreasing (non-increasing) regression
#' @param verb unused (verbosity argument)
#' @return A list.
#' @export
#'
#' @details Returns a list.  A wrapper for fdrtool::monoreg.  Hence, chose
#'   not to change the name, although this could lead to confusing errors at
#'   times.  Component ff is the estimate values, xx, yy are the input values
#'   (sorted by xx) Component $L gives the residual sum of squares divided by
#'   sample size, $S gives sum of squares (not divided by nn).  This mostly
#'   exists to package the output of a monotone regression in the same format
#'   as the output of monoreg_VC in this package.
#'
#' @examples
#'
#' nn <- 100
#' xx <- sort(runif(nn, 0,1))
#' ff <- function(xx){xx}
#' yy <- ff(xx) + rnorm(nn, sd=.5)
#' out <- monoreg(xx=xx,yy=yy, type="isotonic")


monoreg <- function(xx, yy,
                    type="isotonic",
                    verb=0
                    ){
    nn <- length(xx)
    if (nn != length(yy)) stop("Require length(xx) == length(yy).")
    if (anyNA(xx) || anyNA(yy))  stop("missing values not allowed")
    isOrd <- !is.unsorted(xx, strictly = TRUE)
    if (!isOrd){
        oo <- order(xx,-yy)
        xx <- xx[oo]
        yy <- yy[oo]
    }
    if (length(unique(xx))<nn) stop("Require xx to have unique entries.")
    ## actual work
    out.UC <- fdrtool::monoreg(xx, yy, type=type)
    S.UC <- sum((out.UC$yf - out.UC$y)^2)
    list(ff=out.UC$yf, L=S.UC/nn, S=S.UC, xx=xx, yy=yy
         )
}
