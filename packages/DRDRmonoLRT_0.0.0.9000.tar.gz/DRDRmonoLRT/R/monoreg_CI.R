## Charles R Doss


#'
#'@title Computes confidence interval for (value/height of) univariate
#'   monotone function.
#'
#' @param xx vector of nn covariate observations (univariate).  Not currently required to be sorted.  Should be unique.  (For nonuniqueness we need an implementation with weights, which are not included here.)
#' @param yy vector of nn response observations (univariate)
#' @param type String "isotonic" (default) for increasing (non-decreasing) or "antitonic" for decreasing (non-increasing) regression
#' @param sigmasq Estimate of variance of errors.  If NULL then an estimate
#'   based on KernSmooth::locpoly is used
#' @param alpha Level for test. Can not currently be vector.
#' @param x0 Scalar numeric: point at which to compute confidence iterval.
#' @param CIprec Tolerance parameter for computing boundary of CI.
#' @param MLE.UC May be NULL.  Otherwise, the output of a call to monoreg() (from this package).
#' @param LRstat_distn For finding alpha level critical (quantile) value.  Either a vector or a "distr" class object.  Or NULL in which case the "flatness" parameter is taken to be 1.  In general, the critical value depends on what we call the "alpha0" flatness parameter.  (VERY different than `alpha', the level of the test.) A positive number, default of 1 (corresponding to a nonzero first derivative in the true dose response curve.)  Only certain values have the corresponding limit distribution simulated.  (Currently  (.01, .2, .4, .6, .8, 1, 2, 5, 10) are supported.)  User does not pass in the alpha0 value currently, they just pass in the corresponding distribution from simulation which can be found elsewhere.  If NULL then only allow the 3 hard coded values for alpha and take alpha0 = 1.
#' @param verb unused (verbosity argument)
#'
#' @return Numeric vector of length 2, a confidence interval.
#'
#' @export
#'
#' @details "Inverts" test from monoreg_LRtest to form a CI.  Forming a CI
#'   for r_0(x_0) where r_0 is the monotonic regression function.  See monoreg_LRtest for more details.
#'



monoreg_CI <-  function(xx,
                        yy,
                        x0, ## scalar, have not implemented vector yet
                        alpha=.05, ## cannot be vector rn; only .05, .1,.15 ok rn
                        CIprec=1e-4,
                        type="isotonic", ## or antitonic
                        MLE.UC = NULL,
                        LRstat_distn = NULL,
                        sigmasq = NULL,
                        verb=0){
  pp <- length(alpha)
  if (is.null(MLE.UC)){
    MLE.UC <- monoreg(xx=xx,
                      yy=yy,
                      type=type,
                      verb=verb) ##UnConstrained
  }

    myLRtest <- function(yy0){monoreg_LRtest(x0=x0, y0_hyp=yy0,
                                             xx=xx, yy=yy,
                                             res.UC=MLE.UC,
                                             res.VC=NULL,
                                             alpha=alpha,
                                             LRstat_distn=LRstat_distn,
                                             sigmasq=sigmasq,
                                             type=type,
                                             verb=verb)}
    y.sort <- sort(yy)

    ## we have to do binary search one alpha-index at a time;
    ## but earlier alphas warm start later alphas

    MLE.UC.f <- approxfun(MLE.UC$xx, MLE.UC$ff)
    rhat <- MLE.UC.f(x0)
    if (verb>1) print(paste("rhat:", rhat))
    if (any(myLRtest(rhat))) ## sanity check
        stop(paste("LR test rejecting unconstrained MLE (at some alpha);",
                   "perhaps alpha is too close to 1."))

    {## now get outer limits of the interval
        supp.len <- tail(y.sort,1)-y.sort[1]
        L.start <- y.sort[1] ## L.start, R.start are starting values for left,right endpoints of interval.
        R.start <- tail(y.sort,1) ##they usually are x[1], x[length(x)].
        ## arbitrary: linearly increase length until exclude endpoint
        count.check <- 0
        while (any(!myLRtest(L.start)) && count.check <= 20){
            L.start <- L.start - supp.len
            count.check <- count.check+1
        }
        if (count.check >=21)
            warning("count.check >= 21, Left: issue with initializing search endpoints.")
        count.check <- 0
        while (any(!myLRtest(R.start)) && count.check <= 20){
            R.start <- R.start + supp.len
            count.check <- count.check+1
        }
        if (count.check >=21)
            warning("count.check >= 21, Right: issue with initializing search endpoints.")
    }

    ## now use binary search starting from L.start, R.start for alpha[1]
    ## (note that all tests rejects L.start and R.start).
    ## For all alphas, keep track of L and R until they disagree with L[ii] and R[ii],
    ## then pick up where you left off..

    Lpts <- vector("numeric",length=pp)
    Rpts <- vector("numeric",length=pp)
    L <- rep(L.start, length=pp)
    R <- rep(rhat, length=pp)
    for (ii in 1:pp){
        while(R[ii]-L[ii] > CIprec){ ##R is in, L is out
            mid <- (R[ii]+L[ii])/2 ## mid for all indices still matching ii'th
            currRes <- !myLRtest(mid)
            match.ii <- (currRes==currRes[ii]) ## keep record for indices matching current one
            R[currRes & match.ii  &  ((1:pp)>= ii)] <- mid
            L[(!currRes) & match.ii  &  ((1:pp)>= ii)] <- mid
        }
        Lpts[ii] <- L[ii]
    }




    ## Do right side
    L <- rep(rhat, length=pp)
    R <- rep(R.start, length=pp)
    for (ii in 1:pp){
        while (R[ii]-L[ii] > CIprec){ ## R is out L is in
            mid <- (R[ii]+L[ii])/2
            currRes <- !myLRtest(mid)
            match.ii <- (currRes==currRes[ii])
            L[currRes & match.ii & ((1:pp) >=ii)] <- mid
            R[(!currRes) & match.ii & ((1:pp) >=ii)] <- mid
        }
        Rpts[ii] <- R[ii]
    }

    ##return(c(Lpt,Rpt))
    return(cbind(Lpts,Rpts))
}
