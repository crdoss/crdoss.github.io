## Value-Constrained monotonic regression


#' @title  Monotonic  regression, value constrained.
#' @param xx vector of nn covariate observations (univariate).  Not currently required to be sorted.  Should be unique.  (For nonuniqueness we need an implementation with weights, which are not included here.)
#' @param yy vector of nn response observations (univariate)
#' @param x0 Location for constraint of regression function. Currently should not be a vector, ie length just one for now.
#' @param y0 Value/Height for contraint of regression function. Can be vector (same length as x0).  Cannot be equal to any xx value; this will be implemented in a version allowing weights passed in eventually.
#' @param type String "isotonic" (default) for increasing (non-decreasing) or "antitonic" for decreasing (non-increasing) regression
#'
#'
#' @return A list.
#' @export
#'
#'
#' @details  Returns a list.   Calls fdrtool::monoreg.  Component ff0  is the
#'     estimate values, xx, yy are the  input values (sorted by xx) Component
#'     $L gives the residual sum of squares divided by sample size
#'
#' @examples
#'
#' nn <- 100
#' xx <- sort(runif(nn, 0,1))
#' ff <- function(xx){xx}
#' yy <- ff(xx) + rnorm(nn, sd=.5)
#' out <- monoreg_VC(xx=xx,yy=yy, x0=.5, y0=.5, type="isotonic")



monoreg_VC <- function(xx, yy,
                       x0, y0,
                       type="isotonic"
                       ##rtol=1e-6,
                       ##                       verb=5
                       ){
    nn <- length(xx)
    mm <- length(x0)
    if (nn != length(yy)) stop("Require length(xx) == length(yy).")
    if (1 != mm || mm != length(y0)) stop("Require length(x0) == length(y0) == 1.")
    if (anyNA(xx) || anyNA(yy) || anyNA(x0) || anyNA(y0))  stop("missing values not allowed")
    isOrd <- !is.unsorted(xx, strictly = TRUE)
    if (!isOrd){
        oo <- order(xx,-yy)
        xx <- xx[oo]
        yy <- yy[oo]
    }
    kk  <-  findInterval(x0, xx)
    if (length(unique(xx))<nn) stop("Require xx to have unique entries.")
    ##if (length(unique(xx))<nn+mm) stop("Currently xx and x0 may not share entries.")

    ##    xx <- c(xx, x0)
    ## NN <- nn+mm ## to be changed depending on uniqueness implementation later
    ## yy <- c(yy, y0)
    ## oo <- order(xx)
    ## rr <- rank(xx)
    ## kk <- tail(rr, mm)
    ## xx <- xx[oo]
    ## yy <- yy[oo]

    ## compute

    xxL <- xx[1:kk]
    xxR <- xx[(kk+1):nn]
    yyL <- yy[1:kk]
    yyR <- yy[(kk+1):nn]


    outL <- fdrtool::monoreg(x=xxL, y=yyL,
                             ## w= xxx ## weight not included now.
                             type=type)
    outR <- fdrtool::monoreg(x=xxR, y=yyR,
                                 ## w= xxx ## weight not included now.
                             type=type)
    if (type=="antitonic"){
        ffL <- pmax(outL$yf, y0);
        ffR <- pmin(outR$yf, y0);
    }
    else if (type=="isotonic"){
        ffL <- pmin(outL$yf, y0);
        ffR <- pmax(outR$yf, y0);
    }
    ff0 <- c(ffL,ffR)
    S <-     sum((yy - ff0)^2)
    L <- S / nn

    list(ff0=ff0, L=L, S=S, xx=xx, yy=yy
         ##        , outL = outL, outR=outR ## temp
         )
}
