

#' @title Likelihood Ratio (i.e., residual sum of squares) Test for r(x_0),
#'   Assuming r is monotone increasing
#' @param res.UC UnConstrained estimator; may be NULL. Otherwise SAME FORMAT
#'   AS OUTPUT FROM monoreg_VC
#' @param res.VC Value-Constrained estimator; may be NULL. Otherwise output
#'   from monoreg_VC.
#' @param sigmasq Estimate of variance of errors.  If NULL then an estimate
#'   based on KernSmooth::locpoly is used
#' @param xx,yy data; used (only) if at least one of res.UC or res.MC or
#'   sigmasq is NULL
#' @param x0,y0_hyp constraint points; used (only) if at least one of res.UC
#'   or res.MC is NULL
#' @param alpha Level for test. Can not currently be vector.
#' @param LRstat_distn For finding alpha level critical (quantile) value.
#'   Either a vector or a "distr" class object.  Or NULL in which case the
#'   "flatness" parameter is taken to be 1.  In general, the critical value
#'   depends on what we call the "alpha0" flatness parameter.  (VERY
#'   different than `alpha', the level of the test.) A positive number,
#'   default of 1 (corresponding to a nonzero first derivative in the true
#'   dose response curve.)  Only certain values have the corresponding limit
#'   distribution simulated.  (Currently (.01, .2, .4, .6, .8, 1, 2, 5, 10)
#'   are supported.)  User does not pass in the alpha0 value currently, they
#'   just pass in the corresponding distribution from simulation which can be
#'   found elsewhere.  If NULL then only allow the 3 hard coded values for
#'   alpha and take alpha0 = 1.  Elements from lists res_stat_list (list with
#'   numeric vector elements) or LRstat_distn_list (list whose elements are
#'   distr objects from package distr) can be used.
#'
#' @param type String "isotonic" (default) for increasing (non-decreasing) or
#'   "antitonic" for decreasing (non-increasing) regression
#' @param verb unused (verbosity argument)
#' @param returntype Can be "test" or "statistic" or "statistic-scaled".  If
#'   the former then a 0 or 1 is returned (the test result); if the
#'   "statistic", the actual ( -2 log likelihood ratio, i.e. RSS) test
#'   statistic is returned (to be compared to the universal quantile after
#'   rescaling). If "statistic-scaled" then returns again the actual RSS test
#'   statistic after rescaling it (thus it is compared directly to the
#'   universal quantile).
#'
#' @return If returntype[1] == "test" then returns TRUE or FALSE.  If
#'   returntype[1]=="statistic" then returns the residual sum of squares
#'   statistic or =="statistic-scaled" then returns the rescaled RSS statistic.
#'
#' @export
#'
#' @details Execute "likelihood ratio" (i.e., residual sum of squares) test.
#'   Calls "monoreg" from this package (note there are other monoreg()
#'   functions in other R packages).  Return value of TRUE means reject,
#'   FALSE means do not reject.  Depending on returntype either returns test output or the statistic.
#'
#'
#'



## [placeholder text for the future...] param alpha0 The flatness parameter.  (VERY different than `alpha', the level of the test.) A positive number, default of 1 (corresponding to a nonzero first derivative in the true dose response curve.)  Only certain values are supported.  Currently should be (.01, .2, .4, .6, .8, 1, 2, 5, 10).

## requires sm.sigma from sm pacakge right now for sigmahat

#### Adding implementation for sigmahat - hasnt been careuflly tested - mar 2018
#### using diff.ord=2 for default.  (add this to an 'example' code.)

monoreg_LRtest <-    function(x0, y0_hyp,
                              xx, yy,
                              ## xgrid, weights not implemented right now
                              ##xgrid=NULL,
                              ## w=NA,
                              res.UC=NULL,
                              res.VC=NULL,
                              ##                              sigmahat=NULL,
                              sigmasq = NULL,
                              ## nn=length(x),
                              alpha=.05,
                              LRstat_distn = NULL,
                              type="isotonic",
                              ##                              rtol=1e-6,
                              verb=0, ## unused
                              returntype = c("test", "statistic", "statistic-scaled", "all")
                              ){
    nn <- length(xx)
    ## if (!exists("LLs"))
    ##     stop(paste("Need LLs object loaded to continue.  Try",
    ##                "load(\"../saves/objects/LL.asymp.exec.MC_nn1000_N.MC10000_cc2.rsav\")"))
    ## if ((!identical(xgrid, NULL) & (!identical(w, NA)))) {
    ##     stop("If w != NA then xgrid must be NULL!\n")
    ## }
    ## if ((!is.numeric(w) || !is.null(xgrid)) && (nn != length(x))) {
    ##     stop("If nn!=length(x), then w must be given a value and xgrid must be NULL.")
    ## }
    if (is.null(res.UC)){

        res.UC <- monoreg(xx, yy, type=type) ## "my" monoreg! CAREFUL
        ## S.UC <- sum((out.UC$yf - out.UC$y)^2)
        ## nn <- length(xx)
        ## res.UC <- list(ff=out.UC$yf,
        ##                S=S.UC,
        ##                L=S.UC/nn,
        ##                xx=xx,yy=yy)
    }
    if (is.null(res.VC)){
        res.VC <- monoreg_VC(xx=xx,yy=yy,x0=x0, y0=y0_hyp, type=type)
    }







    if (is.null(sigmasq)){
      ##stop("incomplete")
      ## sigmahat <- sm.sigma(x=xx,y=yy, diff.ord=2)$estimate
      ## sigmasq <- (sm.sigma(x=xx,y=yy, diff.ord=2)$estimate)^2
      resids2 <- (res.UC$yy - res.UC$ff)^2 ## note: data have been sorted
      sigmasq_fit <- KernSmooth::locpoly(x=res.UC$xx, resids2,
                                         bandwidth = KernSmooth::dpill(res.UC$xx, resids2),
                                         drv=0)
      sigmasq <- approxfun(sigmasq_fit$x, sigmasq_fit$y)(x0)
    }

    LLR <-  (res.VC$S - res.UC$S); ## no factor of 2;
    ## nor factor of n, since $S 's contain *n already

    ## ###### Now execute test.

    ## Get critical value
    if (is(LRstat_distn, "Distribution")){
      QQ <- LRstat_distn@q(1-alpha)
      ##CC <- sigmahat^2 * QQ
    }
    else if (is.numeric(LRstat_distn)){
      QQ <- quantile(LRstat_distn, 1-alpha)
      ## CC <-  sigmahat^2 * QQ
    }
    else { ##
      if (verb > 0) print("NULL value for LRstat_distn; taking beta0=1.") ##beta0 fka alpha0
      ## picked from Table 2 in Banerjee and Wellner 2001
      ## QQs_limit <- c(".85"=1.23,
      ##                ".90"=1.61,
      ##                ".95"=2.26)
      QQs_limit <- matrix(data=c(.85, 1.23,
                                 .90, 1.61,
                                 .95, 2.26), nrow=3, byrow=T)

      alphaInds <- findInterval(1-alpha, QQs_limit[,1])
      ##    QQs_limit[,1] == 1-alpha
      QQ <- QQs_limit[alphaInds,
                      2]
      ##      CC <- sigmahat^2 * QQ ## quantile(LLs, 1-alpha)

    }

    ## if (1){
    ##   X_dens_init <- density(xx)
    ##   X_dens <- approxfun(X_dens_init$x, X_dens_init$y)(x0)
    ##   sigmasq <- sigmasq * X_dens
    ## }


    CC <- sigmasq * QQ


    ##CC <- sigmahat^2 * quantile(LLRs, 1-alpha)


    if (verb > 0){
      ##        print(alphaInds)
      print(paste0("QQ: ", QQ))
      print(paste0("CC ", CC))
      print(paste0("sigmasq: ", sigmasq))
      print(paste0("LLR: ", LLR))
      ## print(res.VC$S)
        ## print(res.UC$S)
    }
    if (returntype[1]=="test") return(LLR > CC) ## [not a vector at this point]
    else if(returntype[1]=="statistic") return(LLR) ## compare to CC (rescaled quantile)
    else if(returntype[1]=="statistic-scaled") return(LLR / sigmasq) ## compare to QQ (universal quantile)
    else if (returntype[1] == "all") return(list(test = LLR > CC,
                                                 stat=LLR,
                                                 statscaled = LLR/sigmasq,
                                                 res.UC=res.UC,
                                                 res.VC=res.VC,
                                                 sigmasq=sigmasq))
}

