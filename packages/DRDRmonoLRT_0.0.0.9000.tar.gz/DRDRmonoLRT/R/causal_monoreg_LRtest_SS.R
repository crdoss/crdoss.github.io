## Causal monotonic/isotonic regression likelihood ratio (residual sum of squares) test with sample splitting


#' @title Likelihood Ratio (i.e., residual sum of squares) Test for r(x_0),
#'   Assuming r is monotone increasing or decreasing, where r is the
#'   dose-response (treatment effect) curve for a continuous treatment
#'   variable (aa) with measured confounders ll.
#' @param yy,aa,ll data: yy is outcome, aa is treatment (a continuous
#'   variable) and ll is the covariate/confounders.
#' @param x0,y0_hyp constraint points;
#' @param alpha Level for test. Can not currently be vector.

#' @param fit_nuisances_subset Function for fitting the nuisance
#'   parameters. See xxx.
#' @param beta0 The flatness. Currently, values are: "0.01" "0.2" "0.4" "0.6" "0.8" "1" "2" "5"
#' @param KK Number of splits. Currently only 1 (no splitting) or 2 is
#'   implemented. NOTE: there is no sanity checking right now that the
#'   LRstat_distn matches.
#' @param type String "isotonic" (default) for increasing (non-decreasing) or "antitonic" for decreasing (non-increasing) regression
#' @param verb unused (verbosity argument)
#' @param returntype Can be "test" or "statistic".  If the former then a 0 or 1 is
#'   returned (the test result); if the latter, the actual ( -2 log likelihood
#'   ratio, i.e. RSS) test statistic is returned.
#'
#' @return If returntype[1] == "test" then returns TRUE or FALSE.  If
#'   returntype[1]=="statistics" then returns the residual sum of squares
#'   statistic.
#'
#' @export
#'
#' @details Implements likelihood ratio / rss test based on possible sample
#'   splitting (SS). Should work with KK=1 (no SS) but this has not yet been
#'   carefully checked. Currently requires large 1gb object storing the numerically convolved limit distribution.
#'

#### OLD
# @param LRstat_distn For finding alpha level critical (quantile) value.
#   Either a vector or a "distr" class object. This depends on KK, but it is
#   up to the user to pass in the correct distribution right now.  In
#   general, the critical value depends on what we call the "alpha0"
#   flatness parameter.  (VERY different than `alpha', the level of the
#   test.) A positive number, default of 1 (corresponding to a nonzero first
#   derivative in the true dose response curve.)  Only certain values have
#   the corresponding limit distribution simulated.  (Currently (.01, .2,
#   .4, .6, .8, 1, 2, 5, 10) are supported.)  User does not pass in the
#   alpha0 value currently, they just pass in the corresponding distribution
#   from simulation which can be found elsewhere.  If NULL then only allow
#   the 3 hard coded values for alpha and take alpha0 = 1.  Elements from
#   lists res_stat_list (list with numeric vector elements) or
#   LRstat_distn_list (list whose elements are distr objects from package
#   distr) can be used.

causal_monoreg_LRtest_SS <-    function(x0, y0_hyp,
                                        yy, aa, ll,
                                        KK = 2,
                                        beta0 = c("0.01", "0.2", "0.4", "0.6", "0.8", "1", "2", "5"),
                                        fit_nuisances_subset,
                                        alpha=.05,
                                        ## LRstat_distn = NULL,
                                        type="isotonic",
                                        verb=0, ## unused
                                        returntype = c("test", "statistic", "statistic-scaled", "all")
                                        ){
  ## if (KK==1) {
  ##   print("Unfortunately, KK==1 is not currently implemented in the _SS version. Use non-SS function. KK must be 2.")
  ##         stop()
  ## }
  ## stopifnot(KK==2)
  myLRstat_distn_quantiles <- DRDRmonoLRTobject::LRstat_distn_SS_mat[KK, , beta0]
  QQ =   quantile(myLRstat_distn_quantiles, probs = 1 - alpha)
  ## if (KK==1) {
  ##   print("Unfortunately, KK==1 is not currently implemented in the _SS version. Use non-SS function. KK must be 2.")
  ##         stop()
  ## }
  ## stopifnot(KK==2)
  ## myLRstat_distn = DRDRmonoLRTobject::LRstat_distn_SS_list[[beta0]][[KK]] ## data object of package; large (~1gb)/ slow!
  ##QQ <- myLRstat_distn@q(1-alpha)
  n_SS <- length(aa);
  lldf <- as.data.frame(ll); ## compatibility with current implementation of fit_nuisances functions
  ##  partitions<-split(1:n_SS,sample(rep(1:KK,times=n_SS/KK)))
  partitions<-split(1:n_SS,sample(rep(1:KK,length=n_SS))) ## allows uneven sizes...

  pseudo.out<-vector("numeric", length=n_SS)
  if (returntype == "all")
    nuisances <- list()

  LRstatsScaled = vector(length=KK)
  for(i in 1:KK){
    ##     fnuis <- fit_nuisances_SL_subset(yy,aa,ll,partitions[[i]],stabweight.low = .1)
    fnuis <- fit_nuisances_subset(yy,aa,lldf, subset=partitions[[i]])
    if (returntype=="all") { ## sanity checking
      nuisances[[i]] <- fnuis
    }
    pseudo.out[partitions[[i]]] <- (fnuis$yy - fnuis$muhat) * fnuis$varpihat / fnuis$pihat + fnuis$mhat
    LRstatsScaled[i] <-      monoreg_LRtest(x0=x0, y0_hyp=y0_hyp,
                                            xx=aa[partitions[[i]]], yy=pseudo.out[partitions[[i]]],
                                            sigmasq=NULL,
                                            ##                   LRstat_distn = myLRstat_distn, ## not used here ...
                                            alpha=alpha,
                                            type=type,
                                            returntype="statistic-scaled",
                                            ##returntype="statistic",
                                            verb=verb)
  }
  avgLRstat <- mean(LRstatsScaled)
  if (returntype[1]=="test") return(avgLRstat>QQ)
  else if (returntype[1]=="statistic")  return(avgLRstat)
  else if (returntype[1] == "all") return(list(test=avgLRstat>QQ,
                                               avgLRstat=avgLRstat,
                                               pseudo.out=pseudo.out,
                                               nuisances=nuisances,
                                               partitions=partitions))
}




## get_pseudos_SS <- function( yy, aa, ll,
##                            KK = 2,
##                            fit_nuisances_subset){
##   returntype = "ignorefornow"
##   n_SS <- length(aa);
##   pseudo.out <- fold_labels <- vector("numeric", length=n_SS)
##   lldf <- as.data.frame(ll); ## compatibility with current implementation of fit_nuisances functions
##   ##  partitions<-split(1:n_SS,sample(rep(1:KK,times=n_SS/KK)))
##   partitions<-split(1:n_SS,sample(rep(1:KK,length=n_SS))) ## allows uneven sizes...


##   if (returntype == "all")
##     nuisances <- list()

##   LRstatsScaled = vector(length=KK)
##   for(i in 1:KK){
##     fold_labels[partitions[[i]]] <- i
##     ##     fnuis <- fit_nuisances_SL_subset(yy,aa,ll,partitions[[i]],stabweight.low = .1)
##     fnuis <- fit_nuisances_subset(yy,aa,lldf, subset=partitions[[i]])
##     if (returntype=="all") { ## sanity checking
##       nuisances[[i]] <- fnuis
##     }
##     pseudo.out[partitions[[i]]] <- (fnuis$yy - fnuis$muhat) * fnuis$varpihat / fnuis$pihat + fnuis$mhat
##   }
##   return(cbind(pseudo.out=pseudo.out, fold=fold_labels))
## }

