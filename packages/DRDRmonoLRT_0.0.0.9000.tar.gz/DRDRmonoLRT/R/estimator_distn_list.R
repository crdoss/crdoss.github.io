#' Monte carlo'd Monotone estimator limiting distribution.
#'
#' Monte Carlo'd distribution of the unconstrained monotone estimator.
#'
#' @format A list "Distribution" object from package distr for different
#'   flatness levels.
#'
#' Beta  values are: "0.01" "0.2" "0.4" "0.6" "0.8" "1" "2" "5"
"estimator_distn_list"
