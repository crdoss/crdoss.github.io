
## Used in a simulation study with :::monoCI_DHZ()

## univariate CI based on Deng Han Zhang
## level must be in a label from the  set
##  names(DHZ_critvals)
## [1] "0.01" "0.02" "0.05" "0.1"  "0.15" "0.2"  "0.5"
## "isoregout" is output from isoreg  (type var?)
## One of level of qq must be null. "qq" can be the critical value or level is the level.
monoCI_DHZ <- function(isoregout,  ## type?)
                       level = "0.1",
                       sig, ## SD not var. vector.  length = num data points. no default
                       qq=NULL){
  DHZ_critvals <- c("0.01"=3.04, "0.02"=2.65, "0.05"=2.11,
                    "0.1"=1.68, "0.15"=1.42, "0.2"=1.23,
                    "0.5" = .59)
  localSS <- diff(c(1,isoregout$iKnots)); ## local sample size ##don't add 1
  if (!is.null(level))
    qq <- DHZ_critvals[level] ## Note: no division by 2 or any such thing here.
  else if (is.null(qq)) stop("Can't have both level and qq be passed as NULL.")

  localSS = diff(c(1, isoregout$iKnots))
  localSS[1] <- localSS[1]+1 ## initial one is off by 1
  localSS_rep <- rep(localSS,  times = localSS)
  denoms <- sqrt(localSS_rep)
  CIradius <- qq * sig / denoms ## sig and denoms should be same length
  ##  isoregout$yf + c(-1,1) * CIradius
  CIu <- isoregout$yf + CIradius
  CIl <- isoregout$yf - CIradius
  return(cbind( "Lower" = CIl, "Upper" = CIu))
}

