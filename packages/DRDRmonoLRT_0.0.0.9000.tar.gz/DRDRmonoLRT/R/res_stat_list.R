#'Likelihood ratio (RSS) statistic distribution
#'
#' Monte Carlo'd distribution of the RSS statistic.
#'
#' @format A list of numeric vectors of simulated RSS values for
#'   differing flatness levels.
#'
#' Beta  values are: "0.01" "0.2" "0.4" "0.6" "0.8" "1" "2" "5"
"LRstat_distn_list"
